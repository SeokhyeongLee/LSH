
package mall.external;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import java.util.Date;

@FeignClient(name="delivery", url="http://localhost:8083") // 서버 상 동기호출(Sync) 라이브러리,  url -> base url 
public interface CancellationService {

    @RequestMapping(method= RequestMethod.POST, path="/cancellations") //base url 뒤에 requestMapping을 통해 path를 붙여서 실행
    public void registerCancelledOrder(@RequestBody Cancellation cancellation);

}